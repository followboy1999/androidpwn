package com.example.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MyReceiver3 extends BroadcastReceiver {
    @Override  // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getBundleExtra("message");

        try {
            Parcel Data = Parcel.obtain();
            bundle.writeToParcel(Data,0);
            byte[] raw = Data.marshall();//序列化
            FileOutputStream fos = null;
            fos  = context.openFileOutput("MyReceiver3.pcl", Context.MODE_PRIVATE);
            fos.write(raw);
            fos.close();
        } catch (FileNotFoundException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        int id = intent.getIntExtra("id", 0);
        String command = bundle.getString("command");

        if(id != 0 && command != null && (command.equals("getflag"))) {
            Log.d("De1ta", "Congratulations! id:" + id);
            return;
        }

        Log.d("De1ta", "Failed in Receiver3! id:" + id);
    }
}

