package com.example.broadcastreceiver;

import android.os.Parcel;
import android.os.Parcelable;

public class Message implements Parcelable {
    public static final Parcelable.Creator<Message> CREATOR = new Parcelable.Creator<Message>() { // from class: com.de1ta.broadcasttest.MainActivity.Message.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public Message createFromParcel(Parcel in) {
            return new Message(in);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public Message[] newArray(int size) {
            return new Message[size];
        }
    };
    String bssid;
    public int burstNumber;
    public int frameNumberPerBurstPeer;
    public int measurementFrameNumber;
    public int measurementType;
    public int retryAfterDuration;
    public int rssi;
    public int rssiSpread;
    public long rtt;
    public long rttSpread;
    public long rttStandardDeviation;
    public int status;
    public int successMeasurementFrameNumber;
    public long ts;
    public int txRate;

    public Message(Parcel in) {
        this.bssid = in.readString();
        this.burstNumber = in.readInt();
        this.measurementFrameNumber = in.readInt();
        this.successMeasurementFrameNumber = in.readInt();
        this.frameNumberPerBurstPeer = in.readInt();
        this.status = in.readInt();
        this.measurementType = in.readInt();
        this.retryAfterDuration = in.readInt();
        this.ts = in.readLong();
        this.rssi = in.readInt();
        this.rssiSpread = in.readInt();
        this.txRate = in.readInt();
        this.rtt = in.readLong();
        this.rttStandardDeviation = in.readLong();
        this.rttSpread = in.readLong();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i) {
        dest.writeString(this.bssid);
        dest.writeInt(this.burstNumber);
        dest.writeInt(this.measurementFrameNumber);
        dest.writeInt(this.successMeasurementFrameNumber);
        dest.writeInt(this.frameNumberPerBurstPeer);
        dest.writeInt(this.status);
        dest.writeInt(this.measurementType);
        dest.writeInt(this.retryAfterDuration);
        dest.writeLong(this.ts);
        dest.writeInt(this.rssi);
        dest.writeInt(this.rssiSpread);
        dest.writeByte((byte) this.txRate);
        dest.writeLong(this.rtt);
        dest.writeLong(this.rttStandardDeviation);
        dest.writeInt((int) this.rttSpread);
    }
}

