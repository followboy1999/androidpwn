package com.example.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Base64;
import android.util.Log;

public class MyReceiver1 extends BroadcastReceiver {
    @Override  // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("id", 0);
        String data = intent.getStringExtra("data");
        if(id != 0 && data != null) {
            try {
                byte[] buffer = Base64.decode(data, 0);
                Parcel dest = Parcel.obtain();
                dest.unmarshall(buffer, 0, buffer.length);
                dest.setDataPosition(0);
                Intent intent1 = new Intent();
                intent1.setAction("com.example.receiver2");
                intent1.setClass(context, MyReceiver2.class);
                Bundle bundle = new Bundle();
                bundle.readFromParcel(dest);
                intent1.putExtra("id", id);
                intent1.putExtra("message", bundle);
                context.sendBroadcast(intent1);
            }
            catch(Exception e) {
                Log.e("De1taDebug", "exception:", e);
                Log.d("De1ta", "Failed in Receiver1! id:" + id);
            }

            return;
        }
    }
}
