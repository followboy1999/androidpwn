package com.example.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MyReceiver2 extends BroadcastReceiver {
    @Override  // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getBundleExtra("message");
        try {
            Parcel Data = Parcel.obtain();
            bundle.writeToParcel(Data,0);
            byte[] raw = Data.marshall();//序列化
            FileOutputStream fos = null;
            fos  = context.openFileOutput("MyReceiver2.pcl", Context.MODE_PRIVATE);
            fos.write(raw);
            fos.close();
        } catch (FileNotFoundException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        int id = intent.getIntExtra("id", 0);
        String command = bundle.getString("command");
        if(id != 0 && command != null && !command.equals("getflag")) {
            try {
                Intent intent1 = new Intent();
                intent1.setAction("com.example.receiver3");
                intent1.setClass(context, MyReceiver3.class);
                intent1.putExtra("id", id);
                intent1.putExtra("message", bundle);
                context.sendBroadcast(intent1);
            }
            catch(Exception e) {
                Log.e("De1taDebug", "exception:", e);
                Log.d("De1ta", "Failed in Receiver2! id:" + id);
            }

            return;
        }

        Log.d("De1ta", "Failed in Receiver2! id:" + id);
    }
}
