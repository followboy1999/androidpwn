package com.example.broadcastreceiver;

import static android.service.controls.ControlsProviderService.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public static final String TAG = "broadcastreceiver";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent1 = new Intent();
        //intent1.setAction("com.de1ta.receiver1");
        //intent1.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        //intent1.setComponent(new ComponentName("com.de1ta.broadcasttest","com.de1ta.broadcasttest.MyReceiver1"));
        //for test
        intent1.setAction("com.example.receiver1");
        intent1.setClass(this,MyReceiver1.class);

        Bundle bundle = new Bundle();
        Parcel des = Parcel.obtain();
        bundle = new MakeBundle().makeMessages();
        bundle.writeToParcel(des,0);
        byte[] raw = des.marshall();//序列化
        String data = Base64.encodeToString(raw,0);
        Log.d(TAG,"Base64 data = " + data);
        intent1.putExtra("id", 666);
        intent1.putExtra("data", data);

        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendBroadcast(intent1);
            }
        });
    }
}